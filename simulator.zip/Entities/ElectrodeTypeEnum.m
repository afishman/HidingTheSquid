classdef ElectrodeTypeEnum < handle
    %ELECTRODETYPEENUM Summary of this class goes here
    %   Detailed explanation goes here
    
    enumeration
        ExternallyControlled, 
        LocallyControlled, 
        Undefined
    end
end

