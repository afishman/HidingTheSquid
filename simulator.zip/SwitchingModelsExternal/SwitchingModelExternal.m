classdef SwitchingModelExternal < SwitchingModel
    %Just an abstract stub for completeness
    properties
    end
    
    methods
    end
end
