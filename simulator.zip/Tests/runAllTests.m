clear all;clc

ThreadTests.Run;
